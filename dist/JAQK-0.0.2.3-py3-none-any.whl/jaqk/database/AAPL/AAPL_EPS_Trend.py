EPS Trend,Current Qtr. (Jun 2019),Next Qtr. (Sep 2019),Current Year (2019)
Current Estimate,2.11,2.72,11.49
7 Days Ago,2.11,2.72,11.49
30 Days Ago,2.08,2.7,11.38
60 Days Ago,2.1,2.7,11.4
90 Days Ago,2.1,2.71,11.4
