Name,Title,Pay,Exercised,Year Born
Mr. Timothy D. Cook,CEO & Director,15.68M,N/A,1961
Mr. Luca Maestri,CFO & Sr. VP,5.02M,N/A,1964
Mr. Jeffrey E. Williams,Chief Operating Officer,5.05M,N/A,1964
Ms. Katherine L. Adams,"Sr. VP, Gen. Counsel & Sec.",5.27M,N/A,1964
Mr. Chris Kondo,Sr. Director of Corp. Accounting,N/A,N/A,N/A
