Statements,12/31/2018,12/31/2017,12/31/2016,12/31/2015
Total Revenue,"232,887,000","177,866,000","135,987,000","107,006,000"
Cost of Revenue,"139,156,000","111,934,000","88,265,000","71,651,000"
Gross Profit,"93,731,000","65,932,000","47,722,000","35,355,000"
Research Development,"28,837,000","22,620,000","16,085,000","12,540,000"
Selling General and Administrative,"52,177,000","38,992,000","27,284,000","20,411,000"
Non Recurring,-,-,-,-
Others,"296,000","214,000","167,000","171,000"
Total Operating Expenses,"220,466,000","173,760,000","131,801,000","104,773,000"
Operating Income or Loss,"12,421,000","4,106,000","4,186,000","2,233,000"
Total Other Income/Expenses Net,"-1,151,000","-304,000","-390,000","-687,000"
Earnings Before Interest and Taxes,"12,421,000","4,106,000","4,186,000","2,233,000"
Interest Expense,"-1,417,000","-848,000","-484,000","-459,000"
Income Before Tax,"11,270,000","3,802,000","3,796,000","1,546,000"
Income Tax Expense,"1,197,000","769,000","1,425,000","950,000"
Minority Interest,-,-,-,-
Net Income From Continuing Ops,"10,073,000","3,033,000","2,371,000","596,000"
Discontinued Operations,-,-,-,-
Extraordinary Items,-,-,-,-
Effect Of Accounting Changes,-,-,-,-
Other Items,-,-,-,-
Net Income,"10,073,000","3,033,000","2,371,000","596,000"
Preferred Stock And Other Adjustments,-,-,-,-
Net Income Applicable To Common Shares,"10,073,000","3,033,000","2,371,000","596,000"
