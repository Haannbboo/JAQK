Statements,12/31/2018,12/31/2017,12/31/2016,12/31/2015
Net Income,"10,073,000","3,033,000","2,371,000","596,000"
Depreciation,"15,341,000","11,478,000","8,116,000","5,646,000"
Adjustments To Net Income,"6,352,000","4,096,000","2,869,000","2,605,000"
Changes In Accounts Receivables,"-4,615,000","-4,780,000","-3,436,000","-1,755,000"
Changes In Liabilities,"4,414,000","7,838,000","6,985,000","5,586,000"
Changes In Inventories,"-1,314,000","-3,583,000","-1,426,000","-2,187,000"
Changes In Other Operating Activities,"472,000","283,000","1,724,000","913,000"
Total Cash Flow From Operating Activities,"30,723,000","18,365,000","17,203,000","12,039,000"
Capital Expenditures,"-13,427,000","-11,955,000","-7,804,000","-5,387,000"
Investments,"1,140,000","-3,054,000","-2,663,000","-1,066,000"
Other Cash flows from Investing Activities,"2,104,000","1,897,000","1,067,000","798,000"
Total Cash Flows From Investing Activities,"-12,369,000","-27,084,000","-9,516,000","-6,450,000"
Dividends Paid,-,-,-,-
Sale Purchase of Stock,-,-,-,-
Net Borrowings,"-7,686,000","9,928,000","-3,716,000","-3,882,000"
Other Cash Flows from Financing Activities,-,-,-,-
Total Cash Flows From Financing Activities,"-7,686,000","9,928,000","-3,716,000","-3,882,000"
Effect Of Exchange Rate Changes,"-351,000","713,000","-212,000","-374,000"
Change In Cash and Cash Equivalents,"10,317,000","1,922,000","3,759,000","1,333,000"
