from .calculations import rank

#from operations.Open import open_file as _open_file

from .factors import cash_flow, income, balance, key, stats





