EPS Trend,Current Qtr. (Jun 2019),Next Qtr. (Sep 2019),Current Year (2019)
Current Estimate,5.49,6.66,27.26
7 Days Ago,5.49,6.66,27.18
30 Days Ago,6.32,7.32,27.43
60 Days Ago,6.37,7.3,27.41
90 Days Ago,6.34,7.26,27.27
