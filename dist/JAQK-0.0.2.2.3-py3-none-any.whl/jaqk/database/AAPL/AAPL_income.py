Statements,9/29/2018,9/30/2017,9/24/2016,9/26/2015
Total Revenue,"265,595,000","229,234,000","215,639,000","233,715,000"
Cost of Revenue,"163,756,000","141,048,000","131,376,000","140,089,000"
Gross Profit,"101,839,000","88,186,000","84,263,000","93,626,000"
Research Development,"14,236,000","11,581,000","10,045,000","8,067,000"
Selling General and Administrative,"16,705,000","15,261,000","14,194,000","14,329,000"
Non Recurring,-,-,-,-
Others,-,-,-,-
Total Operating Expenses,"194,697,000","167,890,000","155,615,000","162,485,000"
Operating Income or Loss,"70,898,000","61,344,000","60,024,000","71,230,000"
Total Other Income/Expenses Net,"2,005,000","2,745,000","1,348,000","1,285,000"
Earnings Before Interest and Taxes,"70,898,000","61,344,000","60,024,000","71,230,000"
Interest Expense,"-3,240,000","-2,323,000","-1,456,000","-733,000"
Income Before Tax,"72,903,000","64,089,000","61,372,000","72,515,000"
Income Tax Expense,"13,372,000","15,738,000","15,685,000","19,121,000"
Minority Interest,-,-,-,-
Net Income From Continuing Ops,"59,531,000","48,351,000","45,687,000","53,394,000"
Discontinued Operations,-,-,-,-
Extraordinary Items,-,-,-,-
Effect Of Accounting Changes,-,-,-,-
Other Items,-,-,-,-
Net Income,"59,531,000","48,351,000","45,687,000","53,394,000"
Preferred Stock And Other Adjustments,-,-,-,-
Net Income Applicable To Common Shares,"59,531,000","48,351,000","45,687,000","53,394,000"
