Holder,Shares,Date Reported,% Out
"Vanguard Group, Inc. (The)","338,508,197","Mar 30, 2019",7.36%
Blackrock Inc.,"288,763,237","Mar 30, 2019",6.28%
"Berkshire Hathaway, Inc","249,589,329","Mar 30, 2019",5.42%
State Street Corporation,"190,650,277","Mar 30, 2019",4.14%
"FMR, LLC","100,999,544","Mar 30, 2019",2.20%
"Geode Capital Management, LLC","61,063,812","Mar 30, 2019",1.33%
Northern Trust Corporation,"59,278,139","Mar 30, 2019",1.29%
Norges Bank Investment Management,"47,548,838","Dec 30, 2018",1.03%
Invesco Ltd.,"45,675,431","Mar 30, 2019",0.99%
Bank Of New York Mellon Corporation,"43,319,056","Mar 30, 2019",0.94%
