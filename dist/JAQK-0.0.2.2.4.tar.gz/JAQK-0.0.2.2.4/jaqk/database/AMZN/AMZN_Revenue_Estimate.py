Revenue Estimate,Current Qtr. (Jun 2019),Next Qtr. (Sep 2019),Current Year (2019)
No. of Analysts,39,38,43
Avg. Estimate,62.44B,67.31B,275.18B
Low Estimate,60.97B,65.49B,270.01B
High Estimate,63.76B,70.01B,283.81B
Year Ago Sales,52.89B,56.58B,232.89B
Sales Growth (year/est),18.10%,19.00%,18.20%
