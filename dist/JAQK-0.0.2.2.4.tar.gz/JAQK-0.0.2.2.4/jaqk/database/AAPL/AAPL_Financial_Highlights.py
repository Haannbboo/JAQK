0,1
Fiscal Year Ends,"Sep 29, 2018"
Most Recent Quarter (mrq),"Mar 30, 2019"
Profit Margin,22.12%
Operating Margin (ttm),25.34%
Return on Assets (ttm),11.54%
Return on Equity (ttm),49.13%
Revenue (ttm),258.49B
Revenue Per Share (ttm),54.15
Quarterly Revenue Growth (yoy),-5.10%
Gross Profit (ttm),101.84B
EBITDA,77.34B
Net Income Avi to Common (ttm),57.17B
Diluted EPS (ttm),11.89
Quarterly Earnings Growth (yoy),-16.40%
Total Cash (mrq),80.09B
Total Cash Per Share (mrq),17.41
Total Debt (mrq),112.63B
Total Debt/Equity (mrq),106.39
Current Ratio (mrq),1.32
Book Value Per Share (mrq),22.98
