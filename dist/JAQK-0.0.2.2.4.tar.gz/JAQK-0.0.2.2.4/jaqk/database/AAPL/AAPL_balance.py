Statements,9/29/2018,9/30/2017,9/24/2016,9/26/2015
Cash And Cash Equivalents,"25,913,000","20,289,000","20,484,000","21,120,000"
Short Term Investments,"40,388,000","53,892,000","46,671,000","20,481,000"
Net Receivables,"48,995,000","35,673,000","29,299,000","30,343,000"
Inventory,"3,956,000","4,855,000","2,132,000","2,349,000"
Other Current Assets,"12,087,000","13,936,000","8,283,000","14,691,000"
Total Current Assets,"131,339,000","128,645,000","106,869,000","89,378,000"
Long Term Investments,"170,799,000","194,714,000","170,430,000","164,065,000"
Property Plant and Equipment,"41,304,000","33,783,000","27,010,000","22,471,000"
Goodwill,-,-,"5,414,000","5,116,000"
Intangible Assets,-,-,"3,206,000","3,893,000"
Accumulated Amortization,-,-,-,-
Other Assets,"22,283,000","18,177,000","8,757,000","5,422,000"
Deferred Long Term Asset Charges,-,-,-,-
Total Assets,"365,725,000","375,319,000","321,686,000","290,345,000"
Accounts Payable,"55,888,000","44,242,000","37,294,000","35,490,000"
Short/Current Long Term Debt,"8,784,000","6,496,000","3,500,000","2,513,000"
Other Current Liabilities,"40,230,000","38,099,000","8,243,000","10,939,000"
Total Current Liabilities,"116,866,000","100,814,000","79,006,000","80,610,000"
Long Term Debt,"93,735,000","97,207,000","75,427,000","53,329,000"
Other Liabilities,"47,977,000","43,251,000","39,004,000","37,051,000"
Deferred Long Term Liability Charges,-,-,-,-
Minority Interest,-,-,-,-
Negative Goodwill,-,-,-,-
Total Liabilities,"258,578,000","241,272,000","193,437,000","170,990,000"
Misc. Stocks Options Warrants,-,-,-,-
Redeemable Preferred Stock,-,-,-,-
Preferred Stock,-,-,-,-
Common Stock,"40,201,000","35,867,000","31,251,000","27,416,000"
Retained Earnings,"70,400,000","98,330,000","96,364,000","92,284,000"
Treasury Stock,"-3,454,000","-150,000","634,000","-345,000"
Capital Surplus,-,-,-,-
Other Stockholder Equity,"-3,454,000","-150,000","634,000","-345,000"
Total Stockholder Equity,"107,147,000","134,047,000","128,249,000","119,355,000"
Net Tangible Assets,"107,147,000","134,047,000","119,629,000","110,346,000"
