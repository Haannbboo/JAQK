Name,Title,Pay,Exercised,Year Born
Mr. Jeffrey P. Bezos,"Founder, Chairman, Pres & CEO",1.68M,N/A,1964
Mr. Brian T. Olsavsky,Sr. VP & CFO,163.2k,N/A,1964
Mr. Jeffrey M. Blackburn,Sr. VP of Bus. Devel.,178.5k,N/A,1970
Mr. Jeffrey A. Wilke,Chief Exec. Officer of Worldwide Consumer,255.61k,N/A,1967
Mr. Andrew R. Jassy,Chief Exec. Officer of Amazon Web Services,266.23k,N/A,1968
