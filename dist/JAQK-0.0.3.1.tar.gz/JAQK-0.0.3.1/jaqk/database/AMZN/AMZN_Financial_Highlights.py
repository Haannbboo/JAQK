0,1
Fiscal Year Ends,"Dec 31, 2018"
Most Recent Quarter (mrq),"Mar 31, 2019"
Profit Margin,4.97%
Operating Margin (ttm),6.17%
Return on Assets (ttm),6.12%
Return on Equity (ttm),30.06%
Revenue (ttm),241.55B
Revenue Per Share (ttm),494.21
Quarterly Revenue Growth (yoy),17.00%
Gross Profit (ttm),93.73B
EBITDA,31.44B
Net Income Avi to Common (ttm),12.01B
Diluted EPS (ttm),23.95
Quarterly Earnings Growth (yoy),118.60%
Total Cash (mrq),37.02B
Total Cash Per Share (mrq),75.19
Total Debt (mrq),69.01B
Total Debt/Equity (mrq),142.54
Current Ratio (mrq),1.09
Book Value Per Share (mrq),98.39
