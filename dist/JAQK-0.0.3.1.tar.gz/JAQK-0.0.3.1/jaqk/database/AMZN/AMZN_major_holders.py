Category,Percentage
% of Shares Held by All Insider,16.12%
% of Shares Held by Institutions,57.12%
% of Float Held by Institutions,68.09%
Number of Institutions Holding Shares,"3,378"
