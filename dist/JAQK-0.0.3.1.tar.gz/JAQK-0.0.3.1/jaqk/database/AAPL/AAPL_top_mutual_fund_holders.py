Holder,Shares,Date Reported,% Out
Vanguard Total Stock Market Index Fund,"110,521,153","Sep 29, 2018",2.40%
Vanguard 500 Index Fund,"85,435,882","Sep 29, 2018",1.86%
SPDR S&P 500 ETF Trust,"50,522,136","Mar 30, 2019",1.10%
Vanguard Institutional Index Fund-Institutional Index Fund,"43,783,603","Sep 29, 2018",0.95%
"Invesco ETF Tr-Invesco QQQ Tr, Series 1 ETF","37,515,932","Mar 30, 2019",0.82%
Fidelity 500 Index Fund,"35,045,571","Mar 30, 2019",0.76%
iShares Core S&P 500 ETF,"32,044,086","Mar 30, 2019",0.70%
Vanguard Growth Index Fund,"30,726,434","Sep 29, 2018",0.67%
Vanguard Information Technology Index Fund,"19,643,735","Aug 30, 2018",0.43%
Select Sector SPDR Fund-Technology,"17,431,948","Mar 30, 2019",0.38%
