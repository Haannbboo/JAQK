Stock,Previous Close,Open,Bid,Ask,Day's Range,52 Week Range,Volume,Avg. Volume,Market Cap,Beta (3Y Monthly),PE Ratio (TTM),EPS (TTM),Earnings Date,Forward Dividend & Yield,Ex-Dividend Date,1y Target Est
AAPL,179.66,180.20,178.65 x 1800,178.34 x 900,178.62 - 182.13,142.00 - 233.47,"23,714,686","29,602,092",823.455B,0.89,15.06,11.89,"Jul 29, 2019 - Aug 2, 2019",2.92 (1.46%),2019-05-10,216.17
