Category,Percentage
% of Shares Held by All Insider,0.07%
% of Shares Held by Institutions,60.95%
% of Float Held by Institutions,60.99%
Number of Institutions Holding Shares,"3,860"
