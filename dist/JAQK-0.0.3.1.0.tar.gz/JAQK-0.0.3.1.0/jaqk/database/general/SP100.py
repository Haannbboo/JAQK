Symbol,Name
AAPL,Apple Inc.
ABBV,AbbVie Inc.
ABT,Abbott Laboratories
ACN,Accenture
ADBE,Adobe Inc.
AGN,Allergan
AIG,American International Group
ALL,Allstate
AMGN,Amgen Inc.
AMZN,Amazon.com
AXP,American Express
BA,Boeing Co.
BAC,Bank of America Corp
BIIB,Biogen
BK,The Bank of New York Mellon
BKNG,Booking Holdings
BLK,BlackRock Inc
BMY,Bristol-Myers Squibb
BRK.B,Berkshire Hathaway
C,Citigroup Inc
CAT,Caterpillar Inc.
CELG,Celgene Corp
CHTR,Charter Communications
CL,Colgate-Palmolive
CMCSA,Comcast Corp.
COF,Capital One Financial Corp.
COP,ConocoPhillips
COST,Costco Wholesale Corp.
CSCO,Cisco Systems
CVS,CVS Health
CVX,Chevron Corporation
DHR,Danaher Corporation
DIS,The Walt Disney Company
DOW,Dow Inc.
DUK,Duke Energy
EMR,Emerson Electric Co.
EXC,Exelon
F,Ford Motor Company
FB,Facebook
FDX,FedEx
GD,General Dynamics
GE,General Electric
GILD,Gilead Sciences
GM,General Motors
GOOG,Alphabet Inc. C
GOOGL,Alphabet Inc. A
GS,Goldman Sachs
HD,Home Depot
HON,Honeywell
IBM,International Business Machines
INTC,Intel Corp.
JNJ,Johnson & Johnson
JPM,JPMorgan Chase & Co.
KHC,Kraft Heinz
KMI,Kinder Morgan
KO,The Coca-Cola Company
LLY,Eli Lilly and Company
LMT,Lockheed Martin
LOW,Lowe's
MA,MasterCard Inc
MCD,McDonald's Corp
MDLZ,Mondelēz International
MDT,Medtronic plc
MET,MetLife Inc.
MMM,3M Company
MO,Altria Group
MRK,Merck & Co.
MS,Morgan Stanley
MSFT,Microsoft
NEE,NextEra Energy
NFLX,Netflix
NKE,"Nike, Inc."
NVDA,NVIDIA Corp.
ORCL,Oracle Corporation
OXY,Occidental Petroleum Corp.
PEP,PepsiCo
PFE,Pfizer Inc
PG,Procter & Gamble Co
PM,Philip Morris International
PYPL,PayPal Holdings
QCOM,Qualcomm Inc.
RTN,Raytheon Co.
SBUX,Starbucks Corp.
SLB,Schlumberger
SO,Southern Company
SPG,"Simon Property Group, Inc."
T,AT&T Inc
TGT,Target Corporation
TXN,Texas Instruments
UNH,UnitedHealth Group
UNP,Union Pacific Corporation
UPS,United Parcel Service
USB,U.S. Bancorp
UTX,United Technologies
V,Visa Inc.
VZ,Verizon Communications
WBA,Walgreens Boots Alliance
WFC,Wells Fargo
WMT,Walmart
XOM,Exxon Mobil Corp.
