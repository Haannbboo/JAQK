Revenue Estimate,Current Qtr. (Jun 2019),Next Qtr. (Sep 2019),Current Year (2019)
No. of Analysts,29,29,33
Avg. Estimate,53.52B,61.47B,257.31B
Low Estimate,52.52B,55.26B,251.1B
High Estimate,54.27B,64.77B,261.25B
Year Ago Sales,53.27B,62.9B,265.6B
Sales Growth (year/est),0.50%,-2.30%,-3.10%
