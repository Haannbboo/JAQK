0,1
Market Cap (intraday),823.46B
Enterprise Value,902.14B
Trailing P/E,15.06
Forward P/E,14.00
PEG Ratio (5 yr expected),1.37
Price/Sales (ttm),3.19
Price/Book (mrq),7.79
Enterprise Value/Revenue,3.49
Enterprise Value/EBITDA,11.66
