0,1
Beta (3Y Monthly),1.74
52-Week Change,12.56%
S&P500 52-Week Change,4.92%
52 Week High,"2,050.50"
52 Week Low,"1,307.00"
50-Day Moving Average,"1,881.31"
200-Day Moving Average,"1,704.60"
Avg Vol (3 month),4.35M
Avg Vol (10 day),4M
Shares Outstanding,492.33M
Float,412.73M
% Held by Insiders,16.12%
% Held by Institutions,57.12%
"Shares Short (Apr 30, 2019)",2.63M
"Short Ratio (Apr 30, 2019)",0.68
"Short % of Float (Apr 30, 2019)",0.64%
"Short % of Shares Outstanding (Apr 30, 2019)",0.53%
"Shares Short (prior month Mar 29, 2019)",4.72M
