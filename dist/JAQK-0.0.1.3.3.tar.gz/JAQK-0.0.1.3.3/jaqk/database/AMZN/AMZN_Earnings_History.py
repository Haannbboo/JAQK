Earnings History,6/29/2018,9/29/2018,12/30/2018
EPS Est.,2.54,3.14,5.68
EPS Actual,5.07,5.75,6.04
Difference,2.53,2.61,0.36
Surprise %,99.60%,83.10%,6.30%
