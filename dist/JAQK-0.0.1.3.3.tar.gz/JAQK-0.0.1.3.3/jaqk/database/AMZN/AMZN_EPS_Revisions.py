EPS Revisions,Current Qtr. (Jun 2019),Next Qtr. (Sep 2019),Current Year (2019)
Up Last 7 Days,N/A,N/A,1
Up Last 30 Days,N/A,7,24
Down Last 7 Days,N/A,N/A,N/A
Down Last 30 Days,2,2,N/A
