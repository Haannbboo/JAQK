Earnings Estimate,Current Qtr. (Jun 2019),Next Qtr. (Sep 2019),Current Year (2019)
No. of Analysts,32,31,37
Avg. Estimate,2.11,2.72,11.49
Low Estimate,1.79,1.99,10.71
High Estimate,2.22,2.97,11.8
Year Ago EPS,2.34,2.91,11.91
