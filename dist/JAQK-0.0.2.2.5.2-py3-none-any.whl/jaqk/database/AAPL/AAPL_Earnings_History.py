Earnings History,6/29/2018,9/29/2018,12/30/2018
EPS Est.,2.18,2.78,4.17
EPS Actual,2.34,2.91,4.18
Difference,0.16,0.13,0.01
Surprise %,7.30%,4.70%,0.20%
