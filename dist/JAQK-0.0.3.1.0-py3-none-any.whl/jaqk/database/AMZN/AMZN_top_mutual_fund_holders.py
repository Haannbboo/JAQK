Holder,Shares,Date Reported,% Out
Vanguard Total Stock Market Index Fund,"10,538,608","Sep 29, 2018",2.14%
Vanguard 500 Index Fund,"7,628,516","Sep 29, 2018",1.55%
SPDR S&P 500 ETF Trust,"4,653,551","Mar 30, 2019",0.95%
Fidelity Contrafund Inc,"4,539,093","Mar 30, 2019",0.92%
Growth Fund Of America Inc,"4,298,895","Mar 30, 2019",0.87%
Vanguard Institutional Index Fund-Institutional Index Fund,"3,909,417","Sep 29, 2018",0.79%
"Invesco ETF Tr-Invesco QQQ Tr, Series 1 ETF","3,908,673","Mar 30, 2019",0.79%
Price (T.Rowe) Blue Chip Growth Fund Inc.,"3,312,100","Mar 30, 2019",0.67%
Fidelity 500 Index Fund,"3,228,066","Mar 30, 2019",0.66%
iShares Core S&P 500 ETF,"2,951,598","Mar 30, 2019",0.60%
