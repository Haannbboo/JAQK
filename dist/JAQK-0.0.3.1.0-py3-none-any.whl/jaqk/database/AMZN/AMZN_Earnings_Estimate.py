Earnings Estimate,Current Qtr. (Jun 2019),Next Qtr. (Sep 2019),Current Year (2019)
No. of Analysts,41,40,46
Avg. Estimate,5.49,6.66,27.26
Low Estimate,4.34,4.38,21.53
High Estimate,6.77,8.28,32.68
Year Ago EPS,5.07,5.75,20.14
