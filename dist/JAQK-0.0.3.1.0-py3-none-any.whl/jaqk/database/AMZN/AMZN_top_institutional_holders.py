Holder,Shares,Date Reported,% Out
"Vanguard Group, Inc. (The)","30,925,092","Mar 30, 2019",6.28%
Blackrock Inc.,"25,666,580","Mar 30, 2019",5.21%
"FMR, LLC","16,655,565","Mar 30, 2019",3.38%
State Street Corporation,"16,536,263","Mar 30, 2019",3.36%
Price (T.Rowe) Associates Inc,"15,751,034","Mar 30, 2019",3.20%
"Geode Capital Management, LLC","5,348,606","Mar 30, 2019",1.09%
Invesco Ltd.,"5,054,025","Mar 30, 2019",1.03%
Northern Trust Corporation,"4,939,680","Mar 30, 2019",1.00%
Morgan Stanley,"4,651,353","Mar 30, 2019",0.94%
Baillie Gifford and Company,"4,408,143","Mar 30, 2019",0.90%
