0,1
Market Cap (intraday),897.66B
Enterprise Value,925.8B
Trailing P/E,76.12
Forward P/E,47.84
PEG Ratio (5 yr expected),0.72
Price/Sales (ttm),3.72
Price/Book (mrq),18.53
Enterprise Value/Revenue,3.83
Enterprise Value/EBITDA,29.45
