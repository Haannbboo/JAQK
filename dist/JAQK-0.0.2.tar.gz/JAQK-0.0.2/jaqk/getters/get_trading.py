from pyquery import PyQuery as pq

def get_daily_quote(html):
    pass
