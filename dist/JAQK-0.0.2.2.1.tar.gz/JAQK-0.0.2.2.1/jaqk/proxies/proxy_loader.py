import pandas as pd

def proxy_loader():
    pass
