Growth Estimates,AMZN,Industry,Sector
Current Qtr.,8.30%,N/A,N/A
Next Qtr.,15.80%,N/A,N/A
Current Year,35.40%,N/A,N/A
Next Year,39.80%,N/A,N/A
Next 5 Years (per annum),94.00%,N/A,N/A
Past 5 Years (per annum),103.71%,N/A,N/A
