Growth Estimates,AAPL,Industry,Sector
Current Qtr.,-9.80%,N/A,N/A
Next Qtr.,-6.50%,N/A,N/A
Current Year,-3.50%,N/A,N/A
Next Year,11.20%,N/A,N/A
Next 5 Years (per annum),12.00%,N/A,N/A
Past 5 Years (per annum),12.32%,N/A,N/A
