0,1
Beta (3Y Monthly),0.89
52-Week Change,-4.39%
S&P500 52-Week Change,4.92%
52 Week High,233.47
52 Week Low,142.00
50-Day Moving Average,198.13
200-Day Moving Average,179.17
Avg Vol (3 month),29.6M
Avg Vol (10 day),31.84M
Shares Outstanding,4.6B
Float,4.35B
% Held by Insiders,0.07%
% Held by Institutions,60.95%
"Shares Short (Apr 30, 2019)",52.67M
"Short Ratio (Apr 30, 2019)",2.19
"Short % of Float (Apr 30, 2019)",1.11%
"Short % of Shares Outstanding (Apr 30, 2019)",1.14%
"Shares Short (prior month Mar 29, 2019)",67.79M
